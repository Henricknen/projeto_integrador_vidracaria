<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="estilos.css">
</head>
<body>
<form name="condutores" action="condut_210.php" method="post">
<table>
<tr><th colspan=2>Cadastro de Condutores - Inclusão</th></tr>
<tr><td>CNH</td>
<td><input type="text" name="cnh" size=15 maxlength=15 required></td></tr>
<tr><td>Nome</td>
<td><input type="text" name="nome" size=30 maxlength=30 required></td></tr>
<tr><td>Data Nascimento</td>
<td><input type="date" name="nasc" size=10 maxlength=10 required></td></tr>
<tr><th>
<input type="submit" name="butinc" value="Gravar">
</th>
</form>
<form name="volta" action="index.html" method="get">
<th>
<input type="submit" name="butvolta" value="Voltar">
</th></tr>
</table>
</form>
</body>
</html>

